import React from 'react';
import './home.css';
import Header from '../../components/Header';

const Home = () => {
  return (
    <div className='body'>  
      <Header/>
    </div>
  )
}

export default Home